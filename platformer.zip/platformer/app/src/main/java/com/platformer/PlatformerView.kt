package com.platformer

// PlatformerView.kt

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.random.Random

class PlatformerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr), Runnable {

    private enum class GameState {
        MENU, PLAYING, PAUSED, GAME_OVER
    }

    private var gameState = GameState.MENU
    private var thread: Thread? = null
    private var isRunning = false
    private val holder: SurfaceHolder = getHolder()

    private lateinit var player: Player
    private val platforms = mutableListOf<Platform>()
    private var viewWidth = 0
    private var viewHeight = 0
    private var respawnTimer = 0L
    private val maxFallTime = 2000L
    private val random = Random(System.currentTimeMillis())

    private val camera = Rect()
    private val cameraOffset = PointF()

    private val buttonRects = mutableMapOf<String, RectF>()
    private var touchDownTime = 0L
    private val minTouchDuration = 30L
    private var lastFrameTime = System.currentTimeMillis()
    private val targetFPS = 60
    private val frameTime = 1000 / targetFPS

    // Reusable objects
    private val tempRect = RectF()
    private val tempPoint = PointF()

    // Paint objects
    private val playerPaint = Paint().apply {
        color = Color.BLUE
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val platformPaint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val backgroundPaint = Paint().apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val textPaint = Paint().apply {
        color = Color.BLACK
        textSize = 60f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        isAntiAlias = true
    }

    private val buttonPaint = Paint().apply {
        color = Color.parseColor("#4CAF50")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val buttonTextPaint = Paint().apply {
        color = Color.WHITE
        textSize = 50f
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        isAntiAlias = true
    }

    private val pauseOverlayPaint = Paint().apply {
        color = Color.argb(180, 0, 0, 0)
        style = Paint.Style.FILL
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        viewWidth = w
        viewHeight = h
        camera.set(0, 0, w, h)
        initButtons()
        generateInitialLevel(h)
    }

    private fun initButtons() {
        val centerX = viewWidth / 2f
        val buttonWidth = 400f
        val buttonHeight = 150f
        val padding = 30f

        buttonRects.apply {
            put("start", RectF(
                centerX - buttonWidth/2f,
                viewHeight/2f,
                centerX + buttonWidth/2f,
                viewHeight/2f + buttonHeight
            ))
            put("resume", RectF(
                centerX - buttonWidth/2f,
                viewHeight/2f - buttonHeight - padding,
                centerX + buttonWidth/2f,
                viewHeight/2f - padding
            ))
            put("restart", RectF(
                centerX - buttonWidth/2f,
                viewHeight/2f,
                centerX + buttonWidth/2f,
                viewHeight/2f + buttonHeight
            ))
            put("menu", RectF(
                centerX - buttonWidth/2f,
                viewHeight/2f + buttonHeight + padding,
                centerX + buttonWidth/2f,
                viewHeight/2f + buttonHeight * 2 + padding
            ))
        }
    }

    private fun generateInitialLevel(screenHeight: Int) {
        platforms.clear()

        // Start platform
        val startY = screenHeight - 200f
        platforms.add(Platform(10f, startY, 600f, 30f))

        // Generate initial platforms with strict rules
        var lastX = 610f
        var lastY = startY
        val minDistanceX = 200f
        val maxDistanceX = 300f
        val minDistanceY = 80f
        val maxDistanceY = 150f

        repeat(10) {
            val x = lastX + random.nextFloat() * (maxDistanceX - minDistanceX) + minDistanceX
            val y = lastY - random.nextFloat() * (maxDistanceY - minDistanceY) - minDistanceY
            val width = random.nextFloat() * 100f + 150f

            platforms.add(Platform(x, y, width, 30f))
            lastX = x
            lastY = y
        }

        player = Player(
            platforms[0].rect.centerX() - 25f,
            platforms[0].rect.top - 80f,
            50f,
            80f
        )
    }

    private fun generateNewPlatforms() {
        // Remove platforms far behind
        platforms.removeAll { it.rect.right < camera.left - 500 }

        // Generate new platforms with collision check
        while (platforms.last().rect.right < camera.right + 1000) {
            val lastPlatform = platforms.last()
            val minX = lastPlatform.rect.right + 200f
            val maxX = lastPlatform.rect.right + 300f
            val x = random.nextFloat() * (maxX - minX) + minX

            val minY = lastPlatform.rect.top - 150f
            val maxY = lastPlatform.rect.top - 80f
            val y = random.nextFloat() * (maxY - minY) + minY

            val width = random.nextFloat() * 100f + 150f

            // Check for overlaps
            tempRect.set(x, y, x + width, y + 30f)
            val overlaps = platforms.any { RectF.intersects(tempRect, it.rect) }

            if (!overlaps) {
                platforms.add(Platform(x, y, width, 30f))
            } else {
                // Fallback position if overlap detected
                platforms.add(Platform(
                    lastPlatform.rect.right + 250f,
                    lastPlatform.rect.top - 100f,
                    200f,
                    30f
                ))
            }
        }
    }

    override fun run() {
        while (isRunning) {
            val currentTime = System.currentTimeMillis()
            val deltaTime = (currentTime - lastFrameTime).coerceAtMost(100L)
            lastFrameTime = currentTime

            if (!holder.surface.isValid) continue

            val canvas = holder.lockCanvas()
            try {
                synchronized(holder) {
                    when (gameState) {
                        GameState.MENU -> drawMenu(canvas)
                        GameState.PLAYING -> {
                            update(deltaTime)
                            drawGame(canvas)
                        }
                        GameState.PAUSED -> {
                            drawGame(canvas)
                            drawPauseMenu(canvas)
                        }
                        GameState.GAME_OVER -> {
                            drawGame(canvas)
                            drawGameOver(canvas)
                        }
                    }
                }
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }

            val frameProcessingTime = System.currentTimeMillis() - currentTime
            if (frameProcessingTime < frameTime) {
                Thread.sleep(frameTime - frameProcessingTime)
            }
        }
    }

    private fun update(deltaTime: Long) {
        player.update(platforms, deltaTime)
        updateCamera()
        generateNewPlatforms()

        if (!player.isOnGround) {
            if (respawnTimer == 0L) respawnTimer = System.currentTimeMillis()
            else if (System.currentTimeMillis() - respawnTimer > maxFallTime) {
                gameState = GameState.GAME_OVER
            }
        } else {
            respawnTimer = 0L
        }
    }

    private fun updateCamera() {
        tempPoint.x = (player.rect.centerX() + player.width * 2f - viewWidth / 2f)
        tempPoint.y = (player.rect.centerY() - viewHeight / 2f)

        cameraOffset.x += (tempPoint.x - cameraOffset.x) * 0.1f
        cameraOffset.y += (tempPoint.y - cameraOffset.y) * 0.1f

        camera.offsetTo(cameraOffset.x.toInt(), cameraOffset.y.toInt())
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                touchDownTime = System.currentTimeMillis()
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (System.currentTimeMillis() - touchDownTime >= minTouchDuration) {
                    handleTouch(event.x, event.y)
                    return true
                }
            }
        }
        return true
    }

    private fun handleTouch(x: Float, y: Float) {
        when (gameState) {
            GameState.MENU -> buttonRects["start"]?.let { if (it.contains(x, y)) startGame() }
            GameState.PLAYING -> {
                if (y < viewHeight * 0.1f) {
                    gameState = GameState.PAUSED
                } else {
                    player.requestJump()
                }
            }
            GameState.PAUSED -> {
                buttonRects["resume"]?.let { if (it.contains(x, y)) gameState = GameState.PLAYING }
                buttonRects["restart"]?.let { if (it.contains(x, y)) restartGame() }
                buttonRects["menu"]?.let { if (it.contains(x, y)) returnToMenu() }
            }
            GameState.GAME_OVER -> {
                buttonRects["restart"]?.let { if (it.contains(x, y)) restartGame() }
                buttonRects["menu"]?.let { if (it.contains(x, y)) returnToMenu() }
            }
        }
    }

    private fun startGame() {
        gameState = GameState.PLAYING
        generateInitialLevel(viewHeight)
    }

    private fun restartGame() {
        gameState = GameState.PLAYING
        generateInitialLevel(viewHeight)
        cameraOffset.set(0f, 0f)
        camera.offsetTo(0, 0)
    }

    private fun returnToMenu() {
        gameState = GameState.MENU
        generateInitialLevel(viewHeight)
        cameraOffset.set(0f, 0f)
        camera.offsetTo(0, 0)
    }

    private fun drawMenu(canvas: Canvas) {
        canvas.drawRect(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat(), backgroundPaint)
        canvas.drawText("ПЛАТФОРМЕР", viewWidth / 2f, viewHeight / 3f, textPaint)

        buttonRects["start"]?.let {
            canvas.drawRoundRect(it, 20f, 20f, buttonPaint)
            canvas.drawText("НАЧАТЬ", it.centerX(), it.centerY() + 20f, buttonTextPaint)
        }
    }

    private fun drawPauseMenu(canvas: Canvas) {
        canvas.drawRect(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat(), pauseOverlayPaint)
        canvas.drawText("ПАУЗА", viewWidth / 2f, viewHeight / 3f, textPaint)

        buttonRects["resume"]?.let {
            canvas.drawRoundRect(it, 20f, 20f, buttonPaint)
            canvas.drawText("ПРОДОЛЖИТЬ", it.centerX(), it.centerY() + 20f, buttonTextPaint)
        }

        buttonRects["restart"]?.let {
            canvas.drawRoundRect(it, 20f, 20f, buttonPaint)
            canvas.drawText("ЗАНОВО", it.centerX(), it.centerY() + 20f, buttonTextPaint)
        }

        buttonRects["menu"]?.let {
            canvas.drawRoundRect(it, 20f, 20f, buttonPaint)
            canvas.drawText("МЕНЮ", it.centerX(), it.centerY() + 20f, buttonTextPaint)
        }
    }

    private fun drawGameOver(canvas: Canvas) {
        canvas.drawRect(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat(), pauseOverlayPaint)
        canvas.drawText("ПРОИГРЫШ", viewWidth / 2f, viewHeight / 3f, textPaint)

        buttonRects["restart"]?.let {
            canvas.drawRoundRect(it, 20f, 20f, buttonPaint)
            canvas.drawText("ЗАНОВО", it.centerX(), it.centerY() + 20f, buttonTextPaint)
        }

        buttonRects["menu"]?.let {
            canvas.drawRoundRect(it, 20f, 20f, buttonPaint)
            canvas.drawText("МЕНЮ", it.centerX(), it.centerY() + 20f, buttonTextPaint)
        }
    }

    private fun drawGame(canvas: Canvas) {
        canvas.drawRect(0f, 0f, viewWidth.toFloat(), viewHeight.toFloat(), backgroundPaint)
        canvas.save()
        canvas.translate(-camera.left.toFloat(), -camera.top.toFloat())

        // Draw only visible platforms
        val visibleRect = RectF(
            camera.left.toFloat() - 200f,
            camera.top.toFloat() - 200f,
            camera.right.toFloat() + 200f,
            camera.bottom.toFloat() + 200f
        )

        platforms.forEach { platform ->
            if (RectF.intersects(visibleRect, platform.rect)) {
                canvas.drawRect(platform.rect, platformPaint)
            }
        }

        canvas.drawRect(player.rect, playerPaint)
        canvas.restore()
    }

    fun resume() {
        if (!isRunning) {
            isRunning = true
            thread = Thread(this).apply { start() }
            lastFrameTime = System.currentTimeMillis()
        }
    }

    fun pause() {
        isRunning = false
        thread?.join()
        thread = null
    }

    class Player(var x: Float, var y: Float, val width: Float, val height: Float) {
        var velocityX = 0f
        var velocityY = 0f
        var isOnGround = false
        private var jumpRequested = false
        private val jumpForce = -22f

        val rect: RectF
            get() = RectF(x, y, x + width, y + height)

        fun requestJump() {
            if (isOnGround) {
                jumpRequested = true
            }
        }

        fun update(platforms: List<Platform>, deltaTime: Long) {
            val delta = deltaTime / 16f // Normalize to 60 FPS

            // Horizontal movement
            velocityX = 6f * delta

            // Apply gravity if not on ground
            if (!isOnGround) {
                velocityY += 0.8f * delta
            }

            // Cap fall speed
            velocityY = velocityY.coerceAtMost(20f)

            // Handle jump
            if (jumpRequested && isOnGround) {
                velocityY = jumpForce * delta
                isOnGround = false
                jumpRequested = false
            }

            // Save old position for collision detection
            val oldX = x
            val oldY = y

            // Move horizontally
            x += velocityX
            isOnGround = false

            // Check horizontal collisions
            for (platform in platforms) {
                if (RectF.intersects(rect, platform.rect)) {
                    x = oldX
                    break
                }
            }

            // Move vertically
            y += velocityY

            // Check vertical collisions
            for (platform in platforms) {
                if (RectF.intersects(rect, platform.rect)) {
                    if (velocityY > 0) { // Falling down
                        isOnGround = true
                        y = platform.rect.top - height
                        velocityY = 0f
                    } else if (velocityY < 0) { // Moving up
                        y = platform.rect.bottom
                        velocityY = 0f
                    }
                    break
                }
            }
        }
    }

    class Platform(val x: Float, val y: Float, val width: Float, val height: Float) {
        val rect: RectF
            get() = RectF(x, y, x + width, y + height)
    }
}